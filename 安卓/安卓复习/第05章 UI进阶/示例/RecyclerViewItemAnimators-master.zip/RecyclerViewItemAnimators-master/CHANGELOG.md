Change Log
===============================================================================

Version 0.3.0 *(2015-11-20)*
----------------------------
* **Appearance animations**
    * Added `SlideInLeftAnimatorAdapter`
    * Added `SlideInRightAnimatorAdapter`
    * Added `SlideInBottomAnimatorAdapter`
    * Added `ScaleInAnimatorAdapter`

Version 0.2.0 *(2015-11-20)*
----------------------------
* **Appearance animations**
     * Added `AlphaAnimatorAdapter`
* **Animators**
     * Fixed bugs*
* **Library**
     * Added support for last support libraries 23.1.1
     * Updated to gradle 2.4 and gradle plugin 1.3.1

Version 0.1.0
----------------------------
Initial release.
* **Animators**
     * Added `SlideInOutLeftItemAnimator`
     * Added `SlideInOutRightItemAnimator`
     * Added `SlideInOutTopItemAnimator`
     * Added `SlideInOutBottomItemAnimator`
     * Added `ScaleInOutItemAnimator`
     * Added `SlideScaleInOutRightItemAnimator`